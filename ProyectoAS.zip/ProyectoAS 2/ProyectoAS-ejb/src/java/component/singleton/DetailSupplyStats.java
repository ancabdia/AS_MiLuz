/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB31/SingletonEjbClass.java to edit this template
 */
package component.singleton;

import entity.Supplies;
import java.util.ArrayList;
import javax.ejb.Singleton;
import javax.ejb.LocalBean;
import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.Remove;
import javax.ejb.Startup;

/**
 *
 * @author Andres
 */
@Singleton
@LocalBean
@Startup
public class DetailSupplyStats {
    ArrayList<Supplies> detailSupply = new ArrayList<>();
    
    @Lock(LockType.WRITE)
    public void detailSupplyView( Supplies s ){
        detailSupply.add(s);
    }
    
    @Lock(LockType.READ)
    public int getDetailSupplyView(){
        return detailSupply.size();
    }
    
    @Remove
    public void reset(){
        detailSupply.clear();
    }
}
