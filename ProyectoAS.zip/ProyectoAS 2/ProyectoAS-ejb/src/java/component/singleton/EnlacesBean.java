/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package component.singleton;

import component.stateful.SuppliesBean;
import component.stateful.UsersBean;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.EJB;
import javax.ejb.Singleton;
import javax.ejb.LocalBean;
import javax.ejb.Startup;

/**
 *
 * @author Entrar
 */
@Singleton
@LocalBean
@Startup
public class EnlacesBean {

    @EJB
    private LogBean logBean;

    List<UsersBean> users;
    List<SuppliesBean> suppplies;
    
    @PostConstruct
    public void init(){
        users = new ArrayList();
        suppplies = new ArrayList();
    }

    public List<UsersBean> getUsers() {
        return users;
    }

    public List<SuppliesBean> getSuppplies() {
        return suppplies;
    }

    public void addUser(UsersBean u){
        users.add(u);
        logBean.registerLogEntry("usuario añadido al singleton");
    }
    
    public void addSupplies(SuppliesBean s){
        suppplies.add(s);
    }
    
    @PreDestroy
    public void reset(){
        users = new ArrayList();
        suppplies = new ArrayList();
    }
}
