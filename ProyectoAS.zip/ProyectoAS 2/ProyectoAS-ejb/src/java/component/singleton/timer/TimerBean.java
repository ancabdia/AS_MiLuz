/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB31/SingletonEjbClass.java to edit this template
 */
package component.singleton.timer;

import component.singleton.LogBean;
import component.singleton.LoggedUsersStats;
import component.stateful.UsersBean;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Singleton;
import javax.ejb.LocalBean;
import javax.ejb.Startup;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerConfig;
import javax.ejb.TimerService;

/**
 *
 * @author Andres
 */
@Singleton
@LocalBean
@Startup
public class TimerBean {

    @EJB
    private LoggedUsersStats loggedUsersStats;

    Timer UserStatTimer;
    
    @EJB
    private LogBean logBean;

    private long millis;
    private String message = "Llamada Timer Programable";
    
    @Resource
    TimerService timerService;
    
    @PostConstruct
    public void init(){
        millis = 5000;
        UserStatTimer = timerService.createSingleActionTimer(millis, new TimerConfig());
    }
    
    public void setTimer(long millis, String message){
        this.millis = millis;
        this.message = message;
    }

    public long getMillis() {
        return millis;
    }

    public String getMessage() {
        return message;
    }

    @Timeout
    public void timeout(){
        logBean.registerLogEntry(message + " - Usuarios logeados actualmente: " + loggedUsersStats.getUsersLogged());
        UserStatTimer = timerService.createSingleActionTimer(millis, new TimerConfig());
    }
}
