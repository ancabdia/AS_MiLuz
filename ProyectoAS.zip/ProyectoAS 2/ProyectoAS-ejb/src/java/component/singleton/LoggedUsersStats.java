/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB31/SingletonEjbClass.java to edit this template
 */
package component.singleton;

import entity.Users;
import java.util.ArrayList;
import javax.ejb.Singleton;
import javax.ejb.LocalBean;
import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.Schedule;
import javax.ejb.Startup;

/**
 *
 * @author Andres
 */
@Singleton
@LocalBean
@Startup
public class LoggedUsersStats {
    ArrayList<Users> users_logged = new ArrayList<>();
    
    @Lock(LockType.WRITE)
    public void userLogged( Users u ){
        users_logged.add(u);
    }
    
    @Lock(LockType.READ)
    public int getUsersLogged(){
        return users_logged.size();    
    }
    
    public void reset(){
        users_logged.clear();
    }
}
