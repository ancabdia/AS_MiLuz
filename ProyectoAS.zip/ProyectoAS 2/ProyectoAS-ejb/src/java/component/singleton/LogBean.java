/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB31/SingletonEjbClass.java to edit this template
 */
package component.singleton;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.Singleton;
import javax.ejb.LocalBean;
import javax.ejb.Remove;
import javax.ejb.Schedule;
import javax.ejb.Startup;

/**
 *
 * @author Andres
 */
@Singleton
@LocalBean
@Startup
public class LogBean {
    
    SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
    
    Date ultimoRegister;
    Date currentTime;
    
    private List<String> entries;
    
    @Schedule(second="*/5", minute="*", hour="*")
    public void scheduleTimerIfIdle(){
        currentTime = new Date(System.currentTimeMillis());
        
        if(currentTime.getTime() > ultimoRegister.getTime()){
            registerLogEntry("TIMER SCHEDULE");
            System.out.println("TIMER");
        }
    }
    
    @PostConstruct
    private void init(){
        currentTime = new Date(System.currentTimeMillis());
        ultimoRegister = new Date(System.currentTimeMillis());
        entries = new ArrayList();
    }
    
    public void registerLogEntry(String message) {
        System.out.println("entry added to log");
        Date date = new Date(System.currentTimeMillis());
        
        ultimoRegister = date;
        
        String formattedDate = format.format(date);
        entries.add(formattedDate + "   " + message);
    }

    public List<String> getHistory() {
        System.out.println("consulting log historial");
        return this.entries;
    }
    
    @Remove 
    public void removeEntries(){
        System.out.println("entries removed from log");
        entries.removeAll(entries);
    }
    
    @PreDestroy
    public void destroy(){
        System.out.println("entries log destroyed");
        entries.removeAll(entries);
    }
}
