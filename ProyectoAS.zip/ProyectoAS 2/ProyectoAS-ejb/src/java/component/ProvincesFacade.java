/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package component;

import entity.Provinces;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Andres
 */
@Stateless
public class ProvincesFacade extends AbstractFacade<Provinces> {

    @PersistenceContext(unitName = "ProyectoAS-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ProvincesFacade() {
        super(Provinces.class);
    }
    
    public Provinces findPronvinceByName(String parameter) {
        return (Provinces) getEntityManager().createNamedQuery("Provinces.findByProvinceName").setParameter("provinceName", parameter).getSingleResult();
    }    
}
