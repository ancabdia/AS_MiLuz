/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package component;

import entity.Compsumption;
import entity.Supplies;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Andres
 */
@Stateless
public class CompsumptionFacade extends AbstractFacade<Compsumption> {

    @PersistenceContext(unitName = "ProyectoAS-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public CompsumptionFacade() {
        super(Compsumption.class);
    }
    
    public List<Compsumption> findCompsumptionBySupply(Supplies s) {
        List<Compsumption> result = (List<Compsumption>) getEntityManager().createNamedQuery("Compsumption.findBySupply").setParameter("supply", s).getResultList();
        return result;
    }
    
}
