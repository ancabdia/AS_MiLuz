/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package component;

import entity.Comercializadoras;
import entity.Tarifas;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Andres
 */
@Stateless
public class TarifasFacade extends AbstractFacade<Tarifas> {

    @PersistenceContext(unitName = "ProyectoAS-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public TarifasFacade() {
        super(Tarifas.class);
    }
    
    public List<Tarifas> findTarifasByComercializadora(Comercializadoras s) {
        List<Tarifas> result = (List<Tarifas>) getEntityManager().createNamedQuery("Tarifas.findTarifasByComercializadora").setParameter("supply", s).getResultList();
        return result;
    }
    
    public Tarifas findTarifasByName(String s) {
        Tarifas result = (Tarifas) getEntityManager().createNamedQuery("Tarifas.findByTarifaName").setParameter("tarifaName", s).getSingleResult();
        return result;
    }
}
