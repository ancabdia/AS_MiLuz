/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package component;

import entity.Comercializadoras;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Andres
 */
@Stateless
public class ComercializadorasFacade extends AbstractFacade<Comercializadoras> {

    @PersistenceContext(unitName = "ProyectoAS-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ComercializadorasFacade() {
        super(Comercializadoras.class);
    }
    
    public Comercializadoras findComercializadorasByName(String parameter) {
        Comercializadoras s = (Comercializadoras) getEntityManager().createNamedQuery("Comercializadoras.findByComercializadoraName").setParameter("comercializadoraName", parameter).getSingleResult();;
        return s;
    }    
    
}
