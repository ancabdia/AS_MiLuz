  /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/StatefulEjbClass.java to edit this template
 */
package component.stateful;

import component.SuppliesFacade;
import component.UsersFacade;
import component.singleton.LogBean;
import component.singleton.LoggedUsersStats;
import entity.Supplies;
import entity.Users;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.EJB;
import javax.ejb.Stateful;
import javax.ejb.LocalBean;
import javax.ejb.PostActivate;
import javax.ejb.PrePassivate;

/**
 *
 * @author Andres
 */
@Stateful
@LocalBean
//Users para alojar todo lo relacionado con el usario y los supplies
public class UsersBean {

    @EJB
    private LoggedUsersStats loggedUsers;

    Users loggedUser;
    
    @EJB
    private SuppliesFacade suppliesFacade;

    @EJB
    private UsersFacade usersFacade;

    @EJB
    private LogBean logSessionBean;
    
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    
    @PostConstruct
    public void init(){
        loggedUser = null;
    }
    
    public Users findUser(String username){
        logSessionBean.registerLogEntry("UsersBean::findUser()::Users");
        return usersFacade.find(username);
    }
    
    @PostActivate
    public List<Users> getUsers(){
        logSessionBean.registerLogEntry("UsersBean::getUsers()::List<Users>");
        return usersFacade.findAll();
    }

    @PrePassivate
    public void userLogged(Object user){
        Users u = (Users) user;
        loggedUsers.userLogged(u);
        this.setLoggedUser(u);
        logSessionBean.registerLogEntry("UsersBean::userLogged()::" + u.getUsername());
    }
    
    @PreDestroy
    public void userLogout(){
        logSessionBean.registerLogEntry("UsersBean::userLogout()::null");
    }
    
    
    //Aqui crear el remove cuando termina sesion, y el llama @PreDestroy;
    
    //Suministros del usuario
    public List<Supplies> suppliesByUser(Object user){
        Users u = (Users) user;
        List<Supplies> findSuppliesByUser = suppliesFacade.findSuppliesByUser(u);
        logSessionBean.registerLogEntry("UsersBean::suppliesByUser()::List<Supplies>::" + findSuppliesByUser.size());
        return findSuppliesByUser;
    }
    
    public int numberUserLoggedTotal(){
        logSessionBean.registerLogEntry("UsersBean::numberUserLoggedTotal()::int::" + loggedUsers.getUsersLogged());
        return loggedUsers.getUsersLogged();
    }
    
    /**
     * Obtener el usuario logeado
     * @return usuario logeado o null
     */
    @PostActivate
    public Users getLoggedUser() {
        return loggedUser;
    }

    /**
     * Establecer el usuario logeado por el metodo userLogged() y userLogout()
     * @param loggedUser modificar el usuario almacenado 
     */
    public void setLoggedUser(Users loggedUser) {
        this.loggedUser = loggedUser;
    }

    @Override
    public String toString() {
        return "UsersBean{" + " loggedUser=" + loggedUser.toString() + "}";
    }
}
