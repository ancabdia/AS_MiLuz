/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/StatefulEjbClass.java to edit this template
 */
package component.stateful;

import component.SuppliesFacade;
import component.singleton.DetailSupplyStats;
import component.singleton.LogBean;
import entity.Supplies;
import entity.Users;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateful;
import javax.ejb.LocalBean;
import javax.ejb.PostActivate;

/**
 *
 * @author Andres
 */
@Stateful
@LocalBean
public class SuppliesBean {

    @EJB
    private DetailSupplyStats detailSupplyStats;

    @EJB
    private SuppliesFacade suppliesFacade;

    @EJB
    private LogBean logSessionBean;
    
    private List<Supplies> supplies;
    
    public void init(){
        supplies = new ArrayList();
    }

    @PostActivate
    public List<Supplies> getSupplies(Users u) {
        supplies = suppliesFacade.findSuppliesByUser(u);
        logSessionBean.registerLogEntry("SuppliesBean::getSupplies()::List<Supplies>");
        return supplies;
    }
    
    public Supplies supplyDetail(String cups){
        Supplies findSupplyByCUPS = suppliesFacade.findSupplyByCUPS(cups);
        detailSupplyStats.detailSupplyView(findSupplyByCUPS);
        logSessionBean.registerLogEntry("SuppliesBean::supplyDetail()::" + findSupplyByCUPS.getCups());
        return findSupplyByCUPS;
    }
    
    public Supplies supplyCompsumption(String cups){
        Supplies findSupplyByCUPS = suppliesFacade.findSupplyByCUPS(cups);
        logSessionBean.registerLogEntry("SuppliesBean::supplyCompsumption()::");
        return findSupplyByCUPS;
    }
    
    public List<Supplies> findSuppliesFilterByZipCode(int zipCode) {
        List<Supplies> findSuppliesFilterByZipCode = suppliesFacade.findSuppliesFilterByZipCode(zipCode);
        logSessionBean.registerLogEntry("SuppliesBean::findSuppliesFilterByZipCode()::List<Supplies>");
        return findSuppliesFilterByZipCode;
    }
    
    public void removeSupplyByCups(Supplies supply) {
        suppliesFacade.removeSupplyByCups(supply);
        logSessionBean.registerLogEntry("SuppliesBean::removeSupplyByCups()::void");
    }
    
    public List<Supplies> findNextSuppliesFrom(Integer firstResult, Users u) {
        List<Supplies> findNextSuppliesFrom = suppliesFacade.findNextSuppliesFrom(firstResult, u);
        logSessionBean.registerLogEntry("SuppliesBean::findNextSuppliesFrom()::List<Supplies>");
        return findNextSuppliesFrom;
    }
    
    public List<Supplies> findPreviousSuppliesFrom(Integer firstResult) {
        List<Supplies> findNextSuppliesFrom = suppliesFacade.findPreviousSuppliesFrom(firstResult);
        supplies = findNextSuppliesFrom;
        logSessionBean.registerLogEntry("SuppliesBean::findPreviousSuppliesFrom()::List<Supplies>");
        return findNextSuppliesFrom;
    }
    
    public List<Supplies> orderSuppliesASC() {
        List<Supplies> orderSuppliesASC = suppliesFacade.orderSuppliesASC();
        logSessionBean.registerLogEntry("SuppliesBean::orderSuppliesASC()::List<Supplies>");
        return orderSuppliesASC;
    }

    @Override
    public String toString() {
        return "SuppliesBean{" + "detailSupplyStats=" + detailSupplyStats + ", suppliesFacade=" + suppliesFacade + ", logSessionBean=" + logSessionBean + '}';
    }
    
    public List<Supplies> orderSuppliesDESC() {
        List<Supplies> orderSuppliesASC = suppliesFacade.orderSuppliesDESC();
        logSessionBean.registerLogEntry("SuppliesBean::orderSuppliesDESC()::List<Supplies>");
        return orderSuppliesASC;
    }
    
    public void updateSupplyPointType(int pointtype, String cups){
        suppliesFacade.updateSupplyPointType(pointtype, cups);
        logSessionBean.registerLogEntry("SuppliesBean::updateSupplyPointType()::void");
    }
    
    public List<Supplies> suppliesByCityAndTarifa(String city, String tarifa){
        List<Supplies> suppliesByProvinceAndTarifa = suppliesFacade.suppliesByCityAndTarifa("42229164Z",city, tarifa);
        logSessionBean.registerLogEntry("SuppliesBean::suppliesByProvinceAndTarifa()::suppliesByCityAndTarifa");
        return suppliesByProvinceAndTarifa;
    }
}
