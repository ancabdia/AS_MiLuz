/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package component;

import entity.Distributors;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Andres
 */
@Stateless
public class DistributorsFacade extends AbstractFacade<Distributors> {

    @PersistenceContext(unitName = "ProyectoAS-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public DistributorsFacade() {
        super(Distributors.class);
    }
    
    public Distributors findDistributorsByName(String parameter) {
        return (Distributors) getEntityManager().createNamedQuery("Distributors.findByDistributorName").setParameter("distributorName", parameter).getSingleResult();
    }
    
}
