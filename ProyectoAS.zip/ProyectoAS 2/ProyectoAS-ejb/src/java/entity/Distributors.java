/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Andres
 */
@Entity
@Table(name = "DISTRIBUTORS")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Distributors.findAll", query = "SELECT d FROM Distributors d"),
    @NamedQuery(name = "Distributors.findById", query = "SELECT d FROM Distributors d WHERE d.id = :id"),
    @NamedQuery(name = "Distributors.findByNif", query = "SELECT d FROM Distributors d WHERE d.nif = :nif"),
    @NamedQuery(name = "Distributors.findByOrderNumber", query = "SELECT d FROM Distributors d WHERE d.orderNumber = :orderNumber"),
    @NamedQuery(name = "Distributors.findByDistributorName", query = "SELECT d FROM Distributors d WHERE d.distributorName = :distributorName")})
public class Distributors implements Serializable {

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "distribuidora")
    private Collection<Supplies> suppliesCollection;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 9)
    @Column(name = "NIF")
    private String nif;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 6)
    @Column(name = "ORDER_NUMBER")
    private String orderNumber;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "DISTRIBUTOR_NAME")
    private String distributorName;

    public Distributors() {
    }

    public Distributors(Integer id) {
        this.id = id;
    }

    public Distributors(Integer id, String nif, String orderNumber, String distributorName) {
        this.id = id;
        this.nif = nif;
        this.orderNumber = orderNumber;
        this.distributorName = distributorName;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNif() {
        return nif;
    }

    public void setNif(String nif) {
        this.nif = nif;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getDistributorName() {
        return distributorName;
    }

    public void setDistributorName(String distributorName) {
        this.distributorName = distributorName;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Distributors)) {
            return false;
        }
        Distributors other = (Distributors) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Distributors[ id=" + id + " ]";
    }

    @XmlTransient
    public Collection<Supplies> getSuppliesCollection() {
        return suppliesCollection;
    }

    public void setSuppliesCollection(Collection<Supplies> suppliesCollection) {
        this.suppliesCollection = suppliesCollection;
    }
    
}
