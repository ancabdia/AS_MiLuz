/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Andres
 */
@Entity
@Table(name = "COMERCIALIZADORAS")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Comercializadoras.findAll", query = "SELECT c FROM Comercializadoras c"),
    @NamedQuery(name = "Comercializadoras.findById", query = "SELECT c FROM Comercializadoras c WHERE c.id = :id"),
    @NamedQuery(name = "Comercializadoras.findByPhone", query = "SELECT c FROM Comercializadoras c WHERE c.phone = :phone"),
    @NamedQuery(name = "Comercializadoras.findByWeb", query = "SELECT c FROM Comercializadoras c WHERE c.web = :web"),
    @NamedQuery(name = "Comercializadoras.findByComercializadoraName", query = "SELECT c FROM Comercializadoras c WHERE c.comercializadoraName = :comercializadoraName")})
public class Comercializadoras implements Serializable {

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "comercializadoraName")
    private Collection<Tarifas> tarifasCollection;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Column(name = "PHONE")
    private int phone;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "WEB")
    private String web;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "COMERCIALIZADORA_NAME")
    private String comercializadoraName;

    public Comercializadoras() {
    }

    public Comercializadoras(Integer id) {
        this.id = id;
    }

    public Comercializadoras(Integer id, int phone, String web, String comercializadoraName) {
        this.id = id;
        this.phone = phone;
        this.web = web;
        this.comercializadoraName = comercializadoraName;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getPhone() {
        return phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    public String getWeb() {
        return web;
    }

    public void setWeb(String web) {
        this.web = web;
    }

    public String getComercializadoraName() {
        return comercializadoraName;
    }

    public void setComercializadoraName(String comercializadoraName) {
        this.comercializadoraName = comercializadoraName;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Comercializadoras)) {
            return false;
        }
        Comercializadoras other = (Comercializadoras) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Comercializadoras[ id=" + id + " ]";
    }

    @XmlTransient
    public Collection<Tarifas> getTarifasCollection() {
        return tarifasCollection;
    }

    public void setTarifasCollection(Collection<Tarifas> tarifasCollection) {
        this.tarifasCollection = tarifasCollection;
    }
    
}
