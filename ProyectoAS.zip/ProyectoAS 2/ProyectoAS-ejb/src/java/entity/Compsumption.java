/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Andres
 */
@Entity
@Table(name = "COMPSUMPTION")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Compsumption.findAll", query = "SELECT c FROM Compsumption c"),
    
    @NamedQuery(name = "Compsumption.findBySupply", query = "SELECT c FROM Compsumption c WHERE c.supply = :supply"),
    
    @NamedQuery(name = "Compsumption.findByDate", query = "SELECT c FROM Compsumption c WHERE c.date = :date"),
    @NamedQuery(name = "Compsumption.findByTypeFranja", query = "SELECT c FROM Compsumption c WHERE c.typeFranja = :typeFranja"),
    @NamedQuery(name = "Compsumption.findByConsumption", query = "SELECT c FROM Compsumption c WHERE c.consumption = :consumption"),
    @NamedQuery(name = "Compsumption.findById", query = "SELECT c FROM Compsumption c WHERE c.id = :id")})
public class Compsumption implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DATE")
    @Temporal(TemporalType.DATE)
    private Date date;
    @Basic(optional = false)
    @NotNull
    @Column(name = "TYPE_FRANJA")
    private int typeFranja;
    @Basic(optional = false)
    @NotNull
    @Column(name = "CONSUMPTION")
    private int consumption;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID")
    private Integer id;
    @JoinColumn(name = "SUPPLY", referencedColumnName = "ID")
    @ManyToOne(optional = false)
    private Supplies supply;

    public Compsumption() {
    }

    public Compsumption(Integer id) {
        this.id = id;
    }

    public Compsumption(Integer id, Date date, int typeFranja, int consumption) {
        this.id = id;
        this.date = date;
        this.typeFranja = typeFranja;
        this.consumption = consumption;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public int getTypeFranja() {
        return typeFranja;
    }

    public void setTypeFranja(int typeFranja) {
        this.typeFranja = typeFranja;
    }

    public int getConsumption() {
        return consumption;
    }

    public void setConsumption(int consumption) {
        this.consumption = consumption;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Supplies getSupply() {
        return supply;
    }

    public void setSupply(Supplies supply) {
        this.supply = supply;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Compsumption)) {
            return false;
        }
        Compsumption other = (Compsumption) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Compsumption[ id=" + id + " ]";
    }
    
}
