/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Andres
 */
@Entity
@Table(name = "SUPPLIES")
@XmlRootElement
@NamedQueries({
    
    @NamedQuery(name = "Supplies.findAllOfUser", query = "SELECT s FROM Supplies s WHERE s.username = :username"),

    
    @NamedQuery(name = "Supplies.findAll", query = "SELECT s FROM Supplies s"),
    @NamedQuery(name = "Supplies.findByCups", query = "SELECT s FROM Supplies s WHERE s.cups = :cups"),
    @NamedQuery(name = "Supplies.findByValiddatefrom", query = "SELECT s FROM Supplies s WHERE s.validdatefrom = :validdatefrom"),
    @NamedQuery(name = "Supplies.findById", query = "SELECT s FROM Supplies s WHERE s.id = :id"),
    @NamedQuery(name = "Supplies.findByPointtype", query = "SELECT s FROM Supplies s WHERE s.pointtype = :pointtype"),
    @NamedQuery(name = "Supplies.findByValiddateto", query = "SELECT s FROM Supplies s WHERE s.validdateto = :validdateto")})
public class Supplies implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 22)
    @Column(name = "CUPS")
    private String cups;
    @Basic(optional = false)
    @NotNull
    @Column(name = "VALIDDATEFROM")
    @Temporal(TemporalType.DATE)
    private Date validdatefrom;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Column(name = "POINTTYPE")
    private int pointtype;
    @Basic(optional = false)
    @NotNull
    @Column(name = "VALIDDATETO")
    @Temporal(TemporalType.DATE)
    private Date validdateto;
    @JoinColumn(name = "ADDRESS", referencedColumnName = "ID")
    @ManyToOne(optional = false)
    private Addresses address;
    @JoinColumn(name = "DISTRIBUIDORA", referencedColumnName = "DISTRIBUTOR_NAME")
    @ManyToOne(optional = false)
    private Distributors distribuidora;
    @JoinColumn(name = "TARIFA", referencedColumnName = "ID")
    @ManyToOne(optional = false)
    private Tarifas tarifa;
    @JoinColumn(name = "USERNAME", referencedColumnName = "USERNAME")
    @ManyToOne(optional = false)
    private Users username;

    public Supplies() {
    }

    public Supplies(Integer id) {
        this.id = id;
    }

    public Supplies(Integer id, String cups, Date validdatefrom, int pointtype, Date validdateto) {
        this.id = id;
        this.cups = cups;
        this.validdatefrom = validdatefrom;
        this.pointtype = pointtype;
        this.validdateto = validdateto;
    }

    public String getCups() {
        return cups;
    }

    public void setCups(String cups) {
        this.cups = cups;
    }

    public Date getValiddatefrom() {
        return validdatefrom;
    }

    public void setValiddatefrom(Date validdatefrom) {
        this.validdatefrom = validdatefrom;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getPointtype() {
        return pointtype;
    }

    public void setPointtype(int pointtype) {
        this.pointtype = pointtype;
    }

    public Date getValiddateto() {
        return validdateto;
    }

    public void setValiddateto(Date validdateto) {
        this.validdateto = validdateto;
    }

    public Addresses getAddress() {
        return address;
    }

    public void setAddress(Addresses address) {
        this.address = address;
    }

    public Distributors getDistribuidora() {
        return distribuidora;
    }

    public void setDistribuidora(Distributors distribuidora) {
        this.distribuidora = distribuidora;
    }

    public Tarifas getTarifa() {
        return tarifa;
    }

    public void setTarifa(Tarifas tarifa) {
        this.tarifa = tarifa;
    }

    public Users getUsername() {
        return username;
    }

    public void setUsername(Users username) {
        this.username = username;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Supplies)) {
            return false;
        }
        Supplies other = (Supplies) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Supplies[ cups=" + cups + " " + "user= " + username + " ]";
    }
    
}
