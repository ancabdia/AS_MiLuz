/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package frontController;

import control.*;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Andres
 */
public class FrontController extends HttpServlet {

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            FrontCommand command = (FrontCommand) getCommand(request);
            command.init(getServletContext(), request, response);
            command.process();
            
        } catch (Exception ex) {
            Logger.getLogger(FrontController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private FrontCommand getCommand(HttpServletRequest request) throws Exception{
        try{
            FrontCommand f = (FrontCommand) getCommandClass(request).newInstance();
            return f;
        }catch (Exception e){
            throw e;
        }
        
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            FrontCommand command = (FrontCommand) getCommand(request);
            command.init(getServletContext(), request, response);
            command.process();
            
        } catch (Exception ex) {
            Logger.getLogger(FrontController.class.getName()).log(Level.SEVERE, null, ex);
            
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

    private Class getCommandClass(HttpServletRequest request) {
        Class result;
        final String command = "control."+(String)request.getParameter("command");
        try{
            result = Class.forName(command);
        }
        catch(ClassNotFoundException e){
            result=UnknownCommand.class;
        }
        return result;
    }



}
