/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import component.AddressesFacade;
import component.ComercializadorasFacade;
import component.DistributorsFacade;
import component.ProvincesFacade;
import component.SuppliesFacade;
import component.TarifasFacade;
import component.stateful.SuppliesBean;
import component.stateful.UsersBean;
import entity.Addresses;
import entity.Distributors;
import entity.Provinces;
import entity.Supplies;
import entity.Tarifas;
import entity.Users;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import javax.servlet.ServletException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Andres
 */
public class CreateSupplyCommand extends FrontCommand {

    TarifasFacade tarifasFacade = lookupTarifasFacadeBean();

    AddressesFacade addressesFacade = lookupAddressesFacadeBean();

    ComercializadorasFacade comercializadorasFacade = lookupComercializadorasFacadeBean();

    DistributorsFacade distributorsFacade = lookupDistributorsFacadeBean();

    ProvincesFacade provincesFacade = lookupProvincesFacadeBean();

    SuppliesFacade suppliesFacade = lookupSuppliesFacadeBean(); //hay que dejarlo para saber como hacer el create()

    @Override
    public void process() {
        UsersBean usersBean = lookupUsersBeanBean();
        SuppliesBean suppliesBean = lookupSuppliesBeanBean();
        
        try {

            HttpSession session = request.getSession();
            
            
            Users login_usuario = usersBean.getLoggedUser();
            
            String cups = request.getParameter("CUPS");
            
            
            Supplies searchSupply = suppliesBean.supplyDetail(cups);

            if (searchSupply == null) {
                String parameter = request.getParameter("validdatefrom");
                String parameter1 = request.getParameter("validdateto");
                
                
                int pointtype = Integer.parseInt(request.getParameter("pointtype"));
                String tarifa_name = request.getParameter("comercializadora_name");
                String distribuidora_name = request.getParameter("distribuidora_name");

                String street = request.getParameter("street");
                int streetNumber = Integer.parseInt(request.getParameter("street_number"));
                String street2 = request.getParameter("street2");
                String city = request.getParameter("city");
                int zipcode = Integer.parseInt(request.getParameter("zipCode"));
                String province_name = request.getParameter("province");

                Provinces findPronvinceByName = provincesFacade.findPronvinceByName(province_name);

                Distributors findDistributorsByName = distributorsFacade.findDistributorsByName(distribuidora_name);

                Tarifas findTarifasByName = tarifasFacade.findTarifasByName(tarifa_name);
                

                Supplies newSupply = null;
                Addresses address = null;

                if (findPronvinceByName != null) {
                    address = new Addresses();
                    address.setStreet(street);
                    address.setStreet2(street2);
                    address.setStreetNumber(streetNumber);
                    address.setCity(city);
                    address.setZipcode(zipcode);
                    address.setProvince(findPronvinceByName);
                    addressesFacade.create(address);
                }

                if (address != null) {
                    newSupply = new Supplies();
                }
                newSupply.setCups(cups);
                newSupply.setAddress(address);
                newSupply.setUsername(login_usuario);
                newSupply.setPointtype(pointtype);
                
                newSupply.setValiddatefrom(new Date());
                newSupply.setValiddateto(new Date());
                
                newSupply.setTarifa(findTarifasByName);
                newSupply.setDistribuidora(findDistributorsByName);

                suppliesFacade.create(newSupply);
                
                List<Supplies> findNextSuppliesFrom = suppliesBean.findNextSuppliesFrom(0, login_usuario);
                session.setAttribute("pagedSuppliesList", findNextSuppliesFrom);
            }

            forward("/mySupplies.jsp");
        } catch (ServletException ex) {
            Logger.getLogger(CreateSupplyCommand.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(CreateSupplyCommand.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private SuppliesFacade lookupSuppliesFacadeBean() {
        try {
            Context c = new InitialContext();
            return (SuppliesFacade) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/SuppliesFacade!component.SuppliesFacade");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private ProvincesFacade lookupProvincesFacadeBean() {
        try {
            Context c = new InitialContext();
            return (ProvincesFacade) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/ProvincesFacade!component.ProvincesFacade");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private DistributorsFacade lookupDistributorsFacadeBean() {
        try {
            Context c = new InitialContext();
            return (DistributorsFacade) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/DistributorsFacade!component.DistributorsFacade");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private ComercializadorasFacade lookupComercializadorasFacadeBean() {
        try {
            Context c = new InitialContext();
            return (ComercializadorasFacade) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/ComercializadorasFacade!component.ComercializadorasFacade");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private AddressesFacade lookupAddressesFacadeBean() {
        try {
            Context c = new InitialContext();
            return (AddressesFacade) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/AddressesFacade!component.AddressesFacade");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private TarifasFacade lookupTarifasFacadeBean() {
        try {
            Context c = new InitialContext();
            return (TarifasFacade) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/TarifasFacade!component.TarifasFacade");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private UsersBean lookupUsersBeanBean() {
        try {
            Context c = new InitialContext();
            return (UsersBean) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/UsersBean!component.stateful.UsersBean");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private SuppliesBean lookupSuppliesBeanBean() {
        try {
            Context c = new InitialContext();
            return (SuppliesBean) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/SuppliesBean!component.stateful.SuppliesBean");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

}
