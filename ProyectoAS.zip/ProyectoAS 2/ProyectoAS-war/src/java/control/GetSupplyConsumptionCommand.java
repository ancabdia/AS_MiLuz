/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

//import entity.Supplies;
import component.CompsumptionFacade;
import component.SuppliesFacade;
import component.stateful.SuppliesBean;
import component.stateful.UsersBean;
import entity.Compsumption;
import entity.Supplies;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;

/**
 *
 * @author Andres
 */
public class GetSupplyConsumptionCommand extends FrontCommand{
    CompsumptionFacade compsumptionFacade = lookupCompsumptionFacadeBean();

    @Override
    public void process() {
        SuppliesBean suppliesBean = lookupSuppliesBeanBean();
        try {
            String CUPS_detail = request.getParameter("CUPS");
            
            
            Supplies s = suppliesBean.supplyDetail(CUPS_detail);
            
            List<Compsumption> findCompsumptionBySupply = compsumptionFacade.findCompsumptionBySupply(s);
            
            request.setAttribute("suministroComsumption", findCompsumptionBySupply);
            
            
            forward("/supplyConsumption.jsp");
        } catch (ServletException ex) {
            Logger.getLogger(GetPotenciaDetailCommand.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(GetPotenciaDetailCommand.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private CompsumptionFacade lookupCompsumptionFacadeBean() {
        try {
            Context c = new InitialContext();
            return (CompsumptionFacade) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/CompsumptionFacade!component.CompsumptionFacade");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private SuppliesBean lookupSuppliesBeanBean() {
        try {
            Context c = new InitialContext();
            return (SuppliesBean) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/SuppliesBean!component.stateful.SuppliesBean");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    
}
