/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control.filter;

import component.stateful.SuppliesBean;
import component.stateful.UsersBean;
import control.FrontCommand;
import entity.Supplies;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Andres
 */
public class FilterCleanCommand extends FrontCommand{

    @Override
    public void process() {
        HttpSession session = request.getSession();
        
        UsersBean usersBean = (UsersBean)session.getAttribute("usersBean");
        SuppliesBean suppliesBean = (SuppliesBean)session.getAttribute("suppliesBean");
        
        List<Supplies> findSuppliesByUser = usersBean.suppliesByUser(usersBean.getLoggedUser());
        
        List<Supplies> findNextSuppliesFrom = suppliesBean.findNextSuppliesFrom(0, usersBean.getLoggedUser());
        session.setAttribute("pagedSuppliesList", findNextSuppliesFrom);
        
        session.setAttribute("listaSuministros", findSuppliesByUser);
        
        try {
            forward("/mySupplies.jsp");
        } catch (ServletException ex) {
            Logger.getLogger(FilterCleanCommand.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FilterCleanCommand.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    
}
