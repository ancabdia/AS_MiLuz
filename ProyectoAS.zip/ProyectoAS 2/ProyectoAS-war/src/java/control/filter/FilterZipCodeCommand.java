/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control.filter;


import component.SuppliesFacade;
import component.stateful.SuppliesBean;
import control.FrontCommand;
import entity.Supplies;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Andres
 */
public class FilterZipCodeCommand extends FrontCommand{

    //SuppliesFacade supplies_1Facade = lookupSuppliesFacadeBean();

    @Override
    public void process() {
        
        HttpSession session = request.getSession();
        
        SuppliesBean suppliesBean = (SuppliesBean)session.getAttribute("suppliesBean");
        
        int zipCodeReceived = Integer.parseInt(request.getParameter("filterZipCode"));
        
        List<Supplies> listaFiltrada = suppliesBean.findSuppliesFilterByZipCode(zipCodeReceived);
        
        session.setAttribute("pagedSuppliesList", listaFiltrada);
        try {
            forward("/mySupplies.jsp");
        } catch (ServletException ex) {
            Logger.getLogger(FilterZipCodeCommand.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FilterZipCodeCommand.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
