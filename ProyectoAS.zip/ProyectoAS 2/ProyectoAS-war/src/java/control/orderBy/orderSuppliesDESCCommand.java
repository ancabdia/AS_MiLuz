/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control.orderBy;

import component.SuppliesFacade;
import control.FrontCommand;
import entity.Supplies;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Andres
 */
public class orderSuppliesDESCCommand extends FrontCommand{

    SuppliesFacade suppliesFacade = lookupSuppliesFacadeBean();

    @Override
    public void process() {
        HttpSession session = request.getSession();
        
        List<Supplies> orderSuppliesDESC = suppliesFacade.orderSuppliesDESC();
        
        session.setAttribute("pagedSuppliesList", orderSuppliesDESC);
        
        try {
            forward("/mySupplies.jsp");
        } catch (ServletException ex) {
            Logger.getLogger(orderSuppliesDESCCommand.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(orderSuppliesDESCCommand.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private SuppliesFacade lookupSuppliesFacadeBean() {
        try {
            Context c = new InitialContext();
            return (SuppliesFacade) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/SuppliesFacade!component.SuppliesFacade");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }
    
}
