/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import control.filter.FilterCleanCommand;
import component.SuppliesFacade;
import component.UsersFacade;
import entity.Supplies;
import entity.Users;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Andres
 */
public class RemoveCupsCommand extends FrontCommand {

    UsersFacade usersFacade = lookupUsersFacadeBean();

    SuppliesFacade supplies_1Facade = lookupSuppliesFacadeBean();
    @Override
    public void process() {
        HttpSession session = request.getSession();
            Users login_usuario = usersFacade.find( session.getAttribute("user") );

            String cups = request.getParameter("deleteCUPS");
            Supplies removeSupply = supplies_1Facade.findSupplyByCUPS(cups);
            
            if(removeSupply.getUsername().equals(login_usuario))
                supplies_1Facade.removeSupplyByCups(removeSupply);
        
            List<Supplies> findNextSuppliesFrom = supplies_1Facade.findSuppliesByUser(login_usuario);
                session.setAttribute("pagedSuppliesList", findNextSuppliesFrom);
        
            try {
                forward("/mySupplies.jsp");
            } catch (ServletException ex) {
                Logger.getLogger(FilterCleanCommand.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(FilterCleanCommand.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

    private SuppliesFacade lookupSuppliesFacadeBean() {
        try {
            Context c = new InitialContext();
            return (SuppliesFacade) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/SuppliesFacade!component.SuppliesFacade");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private UsersFacade lookupUsersFacadeBean() {
        try {
            Context c = new InitialContext();
            return (UsersFacade) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/UsersFacade!component.UsersFacade");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }
    
    
}
