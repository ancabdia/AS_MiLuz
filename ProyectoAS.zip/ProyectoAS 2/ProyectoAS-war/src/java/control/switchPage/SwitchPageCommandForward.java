/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control.switchPage;

import component.SuppliesFacade;
import component.UsersFacade;
import component.stateful.SuppliesBean;
import component.stateful.UsersBean;
import control.FrontCommand;
import entity.Supplies;
import entity.Users;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Andres
 */
public class SwitchPageCommandForward extends FrontCommand{
    @Override
    public void process() {
        HttpSession session = request.getSession();
        
        UsersBean usersBean = (UsersBean)session.getAttribute("usersBean");
        SuppliesBean suppliesBean = (SuppliesBean)session.getAttribute("suppliesBean");
        
        Users loggedUser = usersBean.getLoggedUser();
        
        Integer pages = (Integer) session.getAttribute("pages");
        Integer currentPage = (Integer) session.getAttribute("currentPage");
        Integer lastResult = (Integer)(session.getAttribute("lastResult"));
        
        if(currentPage < pages){
            session.setAttribute("currentPage", currentPage+1);
            List<Supplies> pagedTickets = suppliesBean.findNextSuppliesFrom(lastResult, loggedUser);
            lastResult = pagedTickets.get(pagedTickets.size()-1).getId();
            session.setAttribute("lastResult", lastResult);
            session.setAttribute("pagedSuppliesList", pagedTickets);
        }
        
        try {
            forward("/mySupplies.jsp");
        } catch (ServletException ex) {
            Logger.getLogger(SwitchPageCommandForward.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(SwitchPageCommandForward.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    
}
