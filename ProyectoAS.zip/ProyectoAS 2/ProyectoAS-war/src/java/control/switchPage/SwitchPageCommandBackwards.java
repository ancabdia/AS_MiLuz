/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control.switchPage;

import component.SuppliesFacade;
import component.stateful.SuppliesBean;
import control.FrontCommand;
import entity.Supplies;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Andres
 */
public class SwitchPageCommandBackwards extends FrontCommand{

    @Override
    public void process() {
        
        HttpSession session = request.getSession();
        
        SuppliesBean suppliesBean = (SuppliesBean)session.getAttribute("suppliesBean");
        
        Integer pages = (Integer) session.getAttribute("pages");
        Integer currentPage = (Integer) session.getAttribute("currentPage");
        
        List<Supplies> pagedSupplies = (List<Supplies>) session.getAttribute("pagedSuppliesList");
        
        Integer lastResult = pagedSupplies.get(0).getId();
        
        if(currentPage > 1){
            currentPage -= 1;
            session.setAttribute("currentPage", currentPage);
            pagedSupplies = suppliesBean.findPreviousSuppliesFrom(lastResult);
            
            if(!pagedSupplies.isEmpty())
                lastResult = pagedSupplies.get(pagedSupplies.size()-1).getId();
            
            session.setAttribute("lastResult", lastResult);
            session.setAttribute("pagedSuppliesList", pagedSupplies);
        }
        
        try {
            forward("/mySupplies.jsp");
        } catch (ServletException ex) {
            Logger.getLogger(SwitchPageCommandBackwards.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(SwitchPageCommandBackwards.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private SuppliesBean lookupSuppliesBeanBean() {
        try {
            Context c = new InitialContext();
            return (SuppliesBean) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/SuppliesBean!component.stateful.SuppliesBean");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }
    
}
