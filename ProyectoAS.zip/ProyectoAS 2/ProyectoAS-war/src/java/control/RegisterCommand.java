/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import component.UsersFacade;
import entity.Users;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Andres
 */
public class RegisterCommand extends FrontCommand{

    UsersFacade usersFacade = lookupUsersFacadeBean();

    @Override
    public void process() {
        try {
            
            HttpSession session = request.getSession();
            String parameter = request.getParameter("username");
            String parameter1 = request.getParameter("password");
            
            //NO existe usuario, se puede crear
            if( usersFacade.find(parameter) == null ){
                Users u = new Users(parameter, parameter1);
                usersFacade.create(u);
                session.setAttribute("user", u);
                forward("/mySupplies.jsp");
            }else{
                forward("/home.jsp");
            }
            
            
        } catch (ServletException ex) {
            Logger.getLogger(LoginCommand.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(LoginCommand.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private UsersFacade lookupUsersFacadeBean() {
        try {
            Context c = new InitialContext();
            return (UsersFacade) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/UsersFacade!component.UsersFacade");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }
    
}
