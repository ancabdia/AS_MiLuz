/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import component.ComercializadorasFacade;
import component.DistributorsFacade;
import component.ProvincesFacade;
import component.TarifasFacade;
import component.singleton.EnlacesBean;
import component.stateful.SuppliesBean;
import component.stateful.UsersBean;
import entity.Comercializadoras;
import entity.Distributors;
import entity.Provinces;
import entity.Supplies;
import entity.Tarifas;
import entity.Users;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Andres
 */
public class LoginCommand extends FrontCommand{

    

    TarifasFacade tarifasFacade = lookupTarifasFacadeBean();

    ProvincesFacade provincesFacade = lookupProvincesFacadeBean();

    DistributorsFacade distributorsFacade = lookupDistributorsFacadeBean();

    ComercializadorasFacade comercializadorasFacade = lookupComercializadorasFacadeBean();

    @Override
    public void process() {
        
        UsersBean usersBean = lookupUsersBeanBean();
        
        SuppliesBean suppliesBean = lookupSuppliesBeanBean();
        
        EnlacesBean enlacesBean = lookupEnlacesBeanBean();
        
        try {
            String usuarioRecibido = request.getParameter("username");
            String passRecibido = request.getParameter("password");
            
            Users find_user = usersBean.findUser(usuarioRecibido);
            
            
            if( (find_user == null) || (!find_user.getPassword().equals(passRecibido)) ){
                forward("/login.jsp");
            }else{
                HttpSession session = request.getSession();
                
                
                List<Supplies> findSuppliesByUser = usersBean.suppliesByUser(find_user);
                
                List<Supplies> findNextSuppliesFrom = suppliesBean.findNextSuppliesFrom(0, find_user);
                session.setAttribute("pagedSuppliesList", findNextSuppliesFrom);
                
                int pages = (int)Math.ceil((double)findSuppliesByUser.size()/5);
                
                session.setAttribute("pages", pages); //Entre 5 por que en el facade puse cada 5 resultados
                
                session.setAttribute("currentPage", 1);
                if(!findNextSuppliesFrom.isEmpty())
                    session.setAttribute("lastResult", findNextSuppliesFrom.get(findNextSuppliesFrom.size()-1).getId());
                else session.setAttribute("lastResult", 0);
                
                
                List<Distributors> distribuidoras = distributorsFacade.findAll();
                List<Comercializadoras> comercializadoras = comercializadorasFacade.findAll();
                List<Provinces> provincias = provincesFacade.findAll();
                List<Tarifas> tarifas = tarifasFacade.findAll();
                
                session.setAttribute("listaComercializadoras", comercializadoras);
                session.setAttribute("listaSuministradoras", distribuidoras);
                session.setAttribute("listaProvinces", provincias);
                session.setAttribute("listaTarifas", tarifas);
                
                
                usersBean.userLogged( find_user );
                
                
                //usersBean.suppliesByCityAndTarifa("Maspalomas", "Ahorro Energia");
                
                //meter el Bean en session
                session.setAttribute("usersBean", usersBean);
                session.setAttribute("suppliesBean", suppliesBean);
                
                
                enlacesBean.addUser(usersBean);
                enlacesBean.addSupplies(suppliesBean);
                
                
                
                
                forward("/mySupplies.jsp");
                
            }

        } catch (ServletException ex) {
            Logger.getLogger(LoginCommand.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(LoginCommand.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private ComercializadorasFacade lookupComercializadorasFacadeBean() {
        try {
            Context c = new InitialContext();
            return (ComercializadorasFacade) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/ComercializadorasFacade!component.ComercializadorasFacade");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private DistributorsFacade lookupDistributorsFacadeBean() {
        try {
            Context c = new InitialContext();
            return (DistributorsFacade) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/DistributorsFacade!component.DistributorsFacade");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private ProvincesFacade lookupProvincesFacadeBean() {
        try {
            Context c = new InitialContext();
            return (ProvincesFacade) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/ProvincesFacade!component.ProvincesFacade");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private TarifasFacade lookupTarifasFacadeBean() {
        try {
            Context c = new InitialContext();
            return (TarifasFacade) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/TarifasFacade!component.TarifasFacade");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private UsersBean lookupUsersBeanBean() {
        try {
            Context c = new InitialContext();
            return (UsersBean) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/UsersBean!component.stateful.UsersBean");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private SuppliesBean lookupSuppliesBeanBean() {
        try {
            Context c = new InitialContext();
            return (SuppliesBean) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/SuppliesBean!component.stateful.SuppliesBean");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private EnlacesBean lookupEnlacesBeanBean() {
        try {
            Context c = new InitialContext();
            return (EnlacesBean) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/EnlacesBean!component.singleton.EnlacesBean");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }
    
}
