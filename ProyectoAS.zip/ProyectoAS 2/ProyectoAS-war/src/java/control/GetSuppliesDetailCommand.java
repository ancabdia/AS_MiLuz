/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

//import entity.Supplies;
import component.SuppliesFacade;
import component.stateful.SuppliesBean;
import component.stateful.UsersBean;
import entity.Supplies;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;

/**
 *
 * @author Andres
 */
public class GetSuppliesDetailCommand extends FrontCommand{

    

    SuppliesFacade supplies_1Facade = lookupSuppliesFacadeBean();
    
    

    @Override
    public void process() {
        SuppliesBean suppliesBean = lookupSuppliesBeanBean();
        try {
            
            String CUPS_detail = request.getParameter("suministroDetail");
            
            
            //Supplies s = supplies_1Facade.findSupplyByCUPS(CUPS_detail);
            Supplies s = suppliesBean.supplyDetail(CUPS_detail);
            
            //profileBean.supplyDetail(CUPS_detail);
            
            request.setAttribute("suministroDetail", s);
            
            forward("/supplyDetail.jsp");
            
        } catch (ServletException ex) {
            Logger.getLogger(GetSuppliesDetailCommand.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(GetSuppliesDetailCommand.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private SuppliesFacade lookupSuppliesFacadeBean() {
        try {
            Context c = new InitialContext();
            return (SuppliesFacade) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/SuppliesFacade!component.SuppliesFacade");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private SuppliesBean lookupSuppliesBeanBean() {
        try {
            Context c = new InitialContext();
            return (SuppliesBean) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/SuppliesBean!component.stateful.SuppliesBean");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }
    
}
