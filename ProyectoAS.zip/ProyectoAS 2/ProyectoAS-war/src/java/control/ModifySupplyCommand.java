/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import component.SuppliesFacade;
import entity.Supplies;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;

/**
 *
 * @author Andres
 */
public class ModifySupplyCommand extends FrontCommand{

    SuppliesFacade suppliesFacade = lookupSuppliesFacadeBean();

    @Override
    public void process() {
        int newPointType = Integer.parseInt(request.getParameter("pointtype"));
        String cups = request.getParameter("cups");
        
        suppliesFacade.updateSupplyPointType(newPointType, cups);
        
        try {
            
            forward("/mySupplies.jsp");
        } catch (ServletException ex) {
            Logger.getLogger(ModifySupplyCommand.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ModifySupplyCommand.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private SuppliesFacade lookupSuppliesFacadeBean() {
        try {
            Context c = new InitialContext();
            return (SuppliesFacade) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/SuppliesFacade!component.SuppliesFacade");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }
    
}
