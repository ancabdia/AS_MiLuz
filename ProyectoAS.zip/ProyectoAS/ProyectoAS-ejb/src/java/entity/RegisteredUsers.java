/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import static entity.Supplies.loader;
import java.util.ArrayList;

/**
 *
 * @author Entrar
 */
public class RegisteredUsers {
    private static ArrayList<User> logins = new ArrayList<User>();
    
    public static void loader(){
        logins.add(new User("42229164Z", "contrasenia1"));
        logins.add(new User("08182995D", "contrasenia"));
    }
    
    public static User checkLogin(String username, String password){
        loader();
        for(User user : logins){
            if(user.getUsername().equals(username) && user.getPassword().equals(password))
                return user;
        }
        return null;
    }
    
    public static boolean registerUser(String username, String password){
        loader();
        
        for(User user : logins){
            if(user.getUsername().equals(username))
                return false;
        }
        logins.add(new User(username, password));
        return true;
    }
}
