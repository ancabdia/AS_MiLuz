/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.util.ArrayList;
/**
 *
 * @author Andres
 */
public class Supplies_old {
    private static ArrayList<Supply_old> supplies;
    
    public static void loader(){  
        supplies = new ArrayList<Supply_old>() {
            {
                add(new Supply_old("42229164Z", "CALLE DOCTOR JOSE CHAMPSAUR SICILIA 9  2 IZQ", "ES0031607020397012YE0F", 35011 , "LAS PALMAS", "Las Palmas de Gran Canaria", "EDISTRIBUCIÓN", 5, 2));
                add(new Supply_old("42229164Z", "AVENIDA ITALIA 19", "ES0031607119747010BW0F", 35100, "LAS PALMAS", "San Bartolome de Tirajana", "EDISTRIBUCIÓN", 5, 2));
                add(new Supply_old("08182995D", "CALLE DOCTOR JOSE CHAMPSAUR SICILIA 9  2 DRC", "ES0024552146322395NL", 35011 , "LAS PALMAS", "Las Palmas de Gran Canaria", "ENDESA", 5, 2));
            }
        };
    }
    
    public static ArrayList<Supply_old> getSupplies(){
        loader();
        return supplies;
    }
    
    public static Supply_old getSupplyFromCUPS(String CUPS){
        loader();
        for(Supply_old s : supplies){
            if(s.getCUPS().equals(CUPS))
                return s;
        }
        return null;
    }
}
