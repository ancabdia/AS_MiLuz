/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import component.AddressesFacade;
import component.SuppliesFacade;
import java.time.LocalDate;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 *
 * @author Andres
 */
public class Supply_old {

    SuppliesFacade supplies_1Facade = lookupSupplies_1FacadeBean();

    AddressesFacade addressesFacade = lookupAddressesFacadeBean();

    
    private String username;
    private String address;
    private String CUPS;
    private Integer postalCode;
    private String province;
    private String municipality;
    private String distributor;
    private Date validDateFrom;
    private Date validDateTo;
    private Integer pointType;
    private Integer distributorCode;
    private Double powerSupplied;
    private Map<Date, Integer> consumptionHistory; //vendra dado en kWh
    
    
    public Supply_old(String username, String address, String CUPS, Integer postalCode, String province, String municipality, String distributor, Date validDateFrom, Date validDateTo, Integer pointType, Integer distributorCode) {
        this.username = username;
        this.address = address;
        this.CUPS = CUPS;
        this.postalCode = postalCode;
        this.province = province;
        this.municipality = municipality;
        this.distributor = distributor;
        this.validDateFrom = validDateFrom;
        this.validDateTo = validDateTo;
        this.pointType = pointType;
        this.distributorCode = distributorCode;
        consumptionHistory = getConsumptionHistory();
    }
    
    public Supply_old(String username, String address, String CUPS, Integer postalCode, String province, String municipality, String distributor, Integer pointType, Integer distributorCode) {
        this.username = username;
        this.address = address;
        this.CUPS = CUPS;
        this.postalCode = postalCode;
        this.province = province;
        this.municipality = municipality;
        this.distributor = distributor;
        this.pointType = pointType;
        this.distributorCode = distributorCode;
        consumptionHistory = getConsumptionHistory();
    }

    /**
     * Minimum data for a Supply
     * @param address
     * @param CUPS
     * @param distributor
     * @param pointType
     * @param distributorCode 
     */
    public Supply_old(String username, String address, String CUPS, String distributor, Integer pointType, Integer distributorCode) {
        this.username = username;
        this.address = address;
        this.CUPS = CUPS;
        this.distributor = distributor;
        this.pointType = pointType;
        this.distributorCode = distributorCode;
        consumptionHistory = getConsumptionHistory();
    }
    
    public String getOwner(){
        return username;
    }

    /**
     * 
     * @return address of supply
     */
    public String getAddress() {
        Addresses find = addressesFacade.find(1);
        return find.getStreet() + ", " + find.getStreetNumber();
    }

    /**
     * 
     * @return CUPS identifier number
     */
    public String getCUPS() {
        return CUPS;
    }

    /**
     * 
     * @return company suministrator of the power
     */
    public String getDistributor() {
        return distributor;
    }

    /**
     * 
     * @return Point type code
     */
    public Integer getPointType() {
        return pointType;
    }

    /**
     * 
     * @return Code of distributor
     */
    public Integer getDistributorCode() {
        return distributorCode;
    }

    public Integer getPostalCode() {
        Addresses find = addressesFacade.find(1);
        
        return find.getZipcode();
    }

    public String getProvince() {
        Addresses find = addressesFacade.find(1);
        
        return find.getProvince().getProvinceName();
        
        
        //Provinces province = provincesFacade.findPronvinceByName("LAS PALMAS");
        //return province.getProvinceName();   
    }

    public String getMunicipality() {
        return municipality;
    }

    public Double getPowerSupplied() {
        int suma = 0;
        for (Map.Entry<Date,Integer> item : getConsumptionHistory().entrySet()){
            suma += item.getValue();
        }
        
        powerSupplied = Double.valueOf((suma/7)/5);
        
        return powerSupplied;
    }

    public Map<Date, Integer> getConsumptionHistory() {
        fillConsumptionHistory();
        return consumptionHistory;
    }
    
    private void fillConsumptionHistory(){
        this.consumptionHistory= new HashMap<>();
        //Getting the current date value
        LocalDate currentdate = LocalDate.now();
        Random r = new Random();
        //Rellenar una semana
        for(int i = 0; i < 7; i++){
            Date date = new Date(currentdate.getYear()-1900, currentdate.getMonthValue() - 1, currentdate.getDayOfMonth()+i);
            consumptionHistory.put(date, r.nextInt(30-0));
        }
        
    }

    private AddressesFacade lookupAddressesFacadeBean() {
        try {
            Context c = new InitialContext();
            return (AddressesFacade) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/AddressesFacade!component.AddressesFacade");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private SuppliesFacade lookupSupplies_1FacadeBean() {
        try {
            Context c = new InitialContext();
            return (SuppliesFacade) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/SuppliesFacade!component.SuppliesFacade");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }
}
