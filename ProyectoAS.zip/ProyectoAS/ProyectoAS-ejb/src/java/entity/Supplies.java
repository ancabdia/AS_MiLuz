/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.util.ArrayList;
/**
 *
 * @author Andres
 */
public class Supplies {
    private static ArrayList<Supply> supplies;
    
    public static void loader(){  
        supplies = new ArrayList<Supply>() {
            {
                add(new Supply("42229164Z", "CALLE DOCTOR JOSE CHAMPSAUR SICILIA 9  2 IZQ", "ES0031607020397012YE0F", 35011 , "LAS PALMAS", "Las Palmas de Gran Canaria", "EDISTRIBUCIÓN", 5, 2));
                add(new Supply("42229164Z", "AVENIDA ITALIA 19", "ES0031607119747010BW0F", 35100, "LAS PALMAS", "San Bartolome de Tirajana", "EDISTRIBUCIÓN", 5, 2));
                add(new Supply("08182995D", "CALLE DOCTOR JOSE CHAMPSAUR SICILIA 9  2 DRC", "ES0024552146322395NL", 35011 , "LAS PALMAS", "Las Palmas de Gran Canaria", "ENDESA", 5, 2));
            }
        };
    }
    
    public static ArrayList<Supply> getSupplies(){
        loader();
        return supplies;
    }
    
    public static Supply getSupplyFromCUPS(String CUPS){
        loader();
        for(Supply s : supplies){
            if(s.getCUPS().equals(CUPS))
                return s;
        }
        return null;
    }
}
