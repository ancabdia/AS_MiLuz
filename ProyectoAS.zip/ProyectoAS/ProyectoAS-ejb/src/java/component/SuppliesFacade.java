/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package component;

import entity.Supplies;
import entity.Users;
import java.util.Collections;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author Andres
 */
@Stateless
public class SuppliesFacade extends AbstractFacade<Supplies> {

    @PersistenceContext(unitName = "ProyectoAS-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SuppliesFacade() {
        super(Supplies.class);
    }
    
    public List<Supplies> findSuppliesByUser(Users user) {
        return (List<Supplies>) getEntityManager().createNamedQuery("Supplies.findAllOfUser").setParameter("username", user).getResultList();
    }
    
    public Supplies findSupplyByCUPS(String cups) {
//        return (Supplies) getEntityManager().createNamedQuery("Supplies.findByCups").setParameter("cups", cups).getSingleResult();
        
        Supplies s = null;
        try{
            s = (Supplies) getEntityManager().createNamedQuery("Supplies.findByCups").setParameter("cups", cups).getSingleResult();
        }catch (NoResultException nre){
            //Ignore this because as per your logic this is ok!
        }
        if(s == null){
            return s;
        }else{
            return s;
        }

        
    }
    
    public List<Supplies> findSuppliesFilterByZipCode(int zipCode) {
        return (List<Supplies>) getEntityManager().createQuery(
                "SELECT s"+
                " FROM Supplies s" +
                " INNER JOIN s.address us" +
                " WHERE us.zipcode = :zipcode").setParameter("zipcode", zipCode).getResultList();
        
        
        /*
        SELECT SUPPLIES.* FROM SUPPLIES
        INNER JOIN ADDRESSES ON SUPPLIES.ADDRESS=ADDRESSES.ID
        WHERE ZIPCODE=35100;

        */
    }
    
    public void removeSupplyByCups(Supplies supply) {
        getEntityManager().createQuery(
                "DELETE FROM Supplies s" +
                        " WHERE s.id = :id").setParameter("id", supply.getId()).executeUpdate();
        getEntityManager().createQuery(
                "DELETE FROM Addresses a" +
                        " WHERE a.id = :id").setParameter("id", supply.getAddress().getId()).executeUpdate();
    }
    
    public List<Supplies> findNextSuppliesFrom(Integer firstResult, Users u) {
        Query queryToDB = em.createQuery("SELECT t FROM Supplies t "
                + "WHERE t.id > :firstResult AND t.username = :username")
                    .setParameter("firstResult", firstResult)
                    .setParameter("username", u)
                    .setMaxResults(5);
        
        List<Supplies> SupplyList = queryToDB.getResultList();
        return SupplyList;
    } 
    
        
    public List<Supplies> findPreviousSuppliesFrom(Integer firstResult) {
        Query queryToDB = em.createQuery("SELECT t FROM Supplies t "
                + "WHERE t.id < :firstResult ORDER BY t.id DESC")
                    .setParameter("firstResult", firstResult)
                    .setMaxResults(5);
        
        List<Supplies> SupplyList = queryToDB.getResultList();
        Collections.reverse(SupplyList);
        return SupplyList;
    }  
    
    public List<Supplies> orderSuppliesASC() {
        return (List<Supplies>) getEntityManager().createQuery(
                "SELECT s"+
                " FROM Supplies s" +
                " ORDER BY s.cups ASC").getResultList();
    }
    
    public List<Supplies> orderSuppliesDESC() {
        return (List<Supplies>) getEntityManager().createQuery(
                "SELECT s"+
                " FROM Supplies s" +
                " ORDER BY s.cups DESC").getResultList();
    }
    
    public void updateSupplyPointType(int pointtype, String cups){
        Query query = em.createQuery(
            "UPDATE Supplies SET pointtype = :pointtype" +
            " WHERE cups = :cups");
        query.setParameter("pointtype", pointtype).setParameter("cups", cups).executeUpdate();
    }
    
}
