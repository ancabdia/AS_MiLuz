/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import entity.RegisteredUsers;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;

/**
 *
 * @author Andres
 */
public class RegisterCommand extends FrontCommand{

    @Override
    public void process() {
        try {
            boolean registerUser = RegisteredUsers.registerUser(request.getParameter("username"), request.getParameter("password"));
            if(registerUser){
                forward("/mySupplies.jsp");
            }else{
                forward("/home.jsp");
            }
            
        } catch (ServletException ex) {
            Logger.getLogger(LoginCommand.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(LoginCommand.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
