/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Andres
 */
public class CloseSessionCommand extends FrontCommand{

    @Override
    public void process() {
        HttpSession session = request.getSession();
        
        session.removeAttribute("username");
        session.removeAttribute("password");
        
        session.removeAttribute("listaSuministros");
        session.removeAttribute("pagedSuppliesList");
        
        session.removeAttribute("pages"); 
        session.removeAttribute("currentPage");
        
        session.removeAttribute("lastResult");
        
        try {
            forward("/home.jsp");
        } catch (ServletException ex) {
            Logger.getLogger(CloseSessionCommand.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(CloseSessionCommand.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
