/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control.switchPage;

import component.SuppliesFacade;
import component.UsersFacade;
import control.FrontCommand;
import entity.Supplies;
import entity.Users;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Andres
 */
public class SwitchPageCommandForward extends FrontCommand{

    UsersFacade usersFacade = lookupUsersFacadeBean();

    SuppliesFacade suppliesFacade = lookupSuppliesFacadeBean();

    @Override
    public void process() {
        HttpSession session = request.getSession();
        
        String usuarioRecibido = (String)session.getAttribute("username");
        
        Users find_user = usersFacade.find(usuarioRecibido);
        
        Integer pages = (Integer) session.getAttribute("pages");
        Integer currentPage = (Integer) session.getAttribute("currentPage");
        Integer lastResult = (Integer)(session.getAttribute("lastResult"));
        
        if(currentPage < pages){
            session.setAttribute("currentPage", currentPage+1);
            List<Supplies> pagedTickets = (List<Supplies>) suppliesFacade.findNextSuppliesFrom(lastResult, find_user);
            lastResult = pagedTickets.get(pagedTickets.size()-1).getId();
            session.setAttribute("lastResult", lastResult);
            session.setAttribute("pagedSuppliesList", pagedTickets);
        }
        
        try {
            forward("/mySupplies.jsp");
        } catch (ServletException ex) {
            Logger.getLogger(SwitchPageCommandForward.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(SwitchPageCommandForward.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private SuppliesFacade lookupSuppliesFacadeBean() {
        try {
            Context c = new InitialContext();
            return (SuppliesFacade) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/SuppliesFacade!component.SuppliesFacade");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private UsersFacade lookupUsersFacadeBean() {
        try {
            Context c = new InitialContext();
            return (UsersFacade) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/UsersFacade!component.UsersFacade");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }
    
}
