/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;

/**
 *
 * @author Andres
 */
public class GetSupplieBillCommand extends FrontCommand{

    @Override
    public void process() {
        try {
            forward("/ServletDownloadBill");
        } catch (ServletException ex) {
            Logger.getLogger(GetPotenciaDetailCommand.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(GetPotenciaDetailCommand.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
