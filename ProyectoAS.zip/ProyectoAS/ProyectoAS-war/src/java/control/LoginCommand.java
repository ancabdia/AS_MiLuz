/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import component.ComercializadorasFacade;
import component.DistributorsFacade;
import component.ProvincesFacade;
import component.SuppliesFacade;
import component.TarifasFacade;
import component.UsersFacade;
import entity.Comercializadoras;
import entity.Distributors;
import entity.Provinces;
import entity.Supplies;
import entity.Tarifas;
import entity.Users;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Andres
 */
public class LoginCommand extends FrontCommand{

    TarifasFacade tarifasFacade = lookupTarifasFacadeBean();

    ProvincesFacade provincesFacade = lookupProvincesFacadeBean();

    DistributorsFacade distributorsFacade = lookupDistributorsFacadeBean();

    ComercializadorasFacade comercializadorasFacade = lookupComercializadorasFacadeBean();

    SuppliesFacade supplies_1Facade = lookupSuppliesFacadeBean();

    UsersFacade usersFacade = lookupUsersFacadeBean();
    
    @Override
    public void process() {
        try {
            String usuarioRecibido = request.getParameter("username");
            String passRecibido = request.getParameter("password");
            
            Users find_user = usersFacade.find(usuarioRecibido);
            
            if( (find_user == null) || (!find_user.getPassword().equals(passRecibido)) ){
                forward("/login.jsp");
            }else{
                HttpSession session = request.getSession();
                session.setAttribute("username", find_user.getUsername());
                session.setAttribute("password", find_user.getPassword());
                
                List<Supplies> findSuppliesByUser = supplies_1Facade.findSuppliesByUser(find_user);
                
                session.setAttribute("listaSuministros", findSuppliesByUser);
                
                List<Supplies> findNextSuppliesFrom = supplies_1Facade.findNextSuppliesFrom(0, find_user);
                session.setAttribute("pagedSuppliesList", findNextSuppliesFrom);
                
                session.setAttribute("pages", (int)(findSuppliesByUser.size()/5)); //Entre 5 por que en el facade puse cada 5 resultados
                
                session.setAttribute("currentPage", 1);
                if(findNextSuppliesFrom.size() > 0)
                    session.setAttribute("lastResult", findNextSuppliesFrom.get(findNextSuppliesFrom.size()-1).getId());
                else session.setAttribute("lastResult", 0);
                
                
                List<Distributors> findAll = distributorsFacade.findAll();
                List<Comercializadoras> findAll1 = comercializadorasFacade.findAll();
                List<Provinces> findAll2 = provincesFacade.findAll();
                List<Tarifas> findAll3 = tarifasFacade.findAll();
                
                session.setAttribute("listaComercializadoras", findAll1);
                session.setAttribute("listaSuministradoras", findAll);
                session.setAttribute("listaProvinces", findAll2);
                session.setAttribute("listaTarifas", findAll3);
                
                
                forward("/mySupplies.jsp");
            }

        } catch (ServletException ex) {
            Logger.getLogger(LoginCommand.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(LoginCommand.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private UsersFacade lookupUsersFacadeBean() {
        try {
            Context c = new InitialContext();
            return (UsersFacade) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/UsersFacade!component.UsersFacade");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private SuppliesFacade lookupSuppliesFacadeBean() {
        try {
            Context c = new InitialContext();
            return (SuppliesFacade) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/SuppliesFacade!component.SuppliesFacade");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private ComercializadorasFacade lookupComercializadorasFacadeBean() {
        try {
            Context c = new InitialContext();
            return (ComercializadorasFacade) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/ComercializadorasFacade!component.ComercializadorasFacade");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private DistributorsFacade lookupDistributorsFacadeBean() {
        try {
            Context c = new InitialContext();
            return (DistributorsFacade) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/DistributorsFacade!component.DistributorsFacade");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private ProvincesFacade lookupProvincesFacadeBean() {
        try {
            Context c = new InitialContext();
            return (ProvincesFacade) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/ProvincesFacade!component.ProvincesFacade");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private TarifasFacade lookupTarifasFacadeBean() {
        try {
            Context c = new InitialContext();
            return (TarifasFacade) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/TarifasFacade!component.TarifasFacade");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }
    
}
