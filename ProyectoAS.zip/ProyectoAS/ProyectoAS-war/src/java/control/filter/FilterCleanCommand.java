/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control.filter;

import component.SuppliesFacade;
import component.UsersFacade;
import control.FrontCommand;
import entity.Supplies;
import entity.Users;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Andres
 */
public class FilterCleanCommand extends FrontCommand{

    SuppliesFacade supplies_1Facade = lookupSuppliesFacadeBean();

    UsersFacade usersFacade = lookupUsersFacadeBean();

    @Override
    public void process() {
        HttpSession session = request.getSession();
        
        String username = (String) session.getAttribute("username");
        
        Users find_user = usersFacade.find(username);
        
        List<Supplies> findSuppliesByUser = supplies_1Facade.findSuppliesByUser(find_user);
        
        List<Supplies> findNextSuppliesFrom = supplies_1Facade.findNextSuppliesFrom(0, find_user);
                session.setAttribute("pagedSuppliesList", findNextSuppliesFrom);
        
        session.setAttribute("listaSuministros", findSuppliesByUser);
        
        try {
            forward("/mySupplies.jsp");
        } catch (ServletException ex) {
            Logger.getLogger(FilterCleanCommand.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FilterCleanCommand.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private UsersFacade lookupUsersFacadeBean() {
        try {
            Context c = new InitialContext();
            return (UsersFacade) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/UsersFacade!component.UsersFacade");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private SuppliesFacade lookupSuppliesFacadeBean() {
        try {
            Context c = new InitialContext();
            return (SuppliesFacade) c.lookup("java:global/ProyectoAS/ProyectoAS-ejb/SuppliesFacade!component.SuppliesFacade");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }
    
}
