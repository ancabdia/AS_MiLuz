/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Andres
 */
public class NewServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            
            out.println(
            
            
            "<form action=\"FrontController\" method=\"POST\"><div class=\"container text-center\"><div class=\"panel panel-default\" >                       <div class=\"panel-heading\" style=\"background: url(https://media.istockphoto.com/vectors/abstract-blurred-colorful-background-vector-id1248542684?k=20&m=1248542684&s=612x612&w=0&h=1yKiRrtPhiqUJXS_yJDwMGVHVkYRk2pJX4PG3TT4ZYM=) no-repeat center center fixed; -webkit-background-size: cover; -moz-background-size: cover; -o-background-size: cover; background-size: cover;\"> <h1>Añadir suministro</h1><p>Rellene los campos para registrar su suminstro en el sistema.</p></div><div class=\"panel-body\"><h4><i class=\"fa-solid fa-lightbulb\"></i>Informacion del suministro:</h4><div class=\"form-group\"><i class=\"fa-solid fa-barcode\"></i>CUPS:<input type=\"text\" name=\"CUPS\" value=\"\" pattern=\"ES00[0-9]{14}[A-Z]{2}0F\" title=\"Formato: ES00______________XX0F\" required/></div><div class=\"form-group\"><i class=\"fa-solid fa-calendar\"></i>Valido desde/hasta: <input type=\"date\" name=\"validdatefrom\" value=\"\" required/> &nbsp/ &nbsp <input type=\"date\" name=\"validdateto\" value=\"\" required/></div><div class=\"form-group\">PointType:<input type=\"text\" name=\"pointtype\" value=\"\" pattern=\"[0-9]{1}\" title=\"Formato: Un unico digito\" required/></div><div class=\"form-group\"><i class=\"fa-solid fa-pipe-section\"></i>Distribuidora:<select name=\"distribuidora_name\" required><option value=\"ENERGIAS DE BENASQUE S.L\">ENERGIAS DE BENASQUE S.L</option><option value=\"ELECTRA REDENERGIA SL\">ELECTRA REDENERGIA SL</option>                                 </select></form>"
            );
            
            
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate=\"collapsed\" desc=\"HttpServlet methods. Click on the + sign on the left to edit the code.\">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
